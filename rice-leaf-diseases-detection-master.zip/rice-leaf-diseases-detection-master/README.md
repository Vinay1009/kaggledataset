# Rice Leaf Disease Detection Using CNN 

For this project,  we are going to detect rice leaf disease by image and serve the result via messenger chatbot. We will also implement this to an independent Android APP.


---


### We have deviced the project into multiple steps


*   Importing Libraries
*   Loading Data
*   Preparing Dataset
*   Label Mapping using Json
*   Data Preproocessing
*   Model Building
*   Trining
*   Check
